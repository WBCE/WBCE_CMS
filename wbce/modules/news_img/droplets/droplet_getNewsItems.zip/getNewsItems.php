if (! file_exists(WB_PATH . '/modules/news_img_anywhere/droplet/nia_droplet.php')) return;
 include(WB_PATH . '/modules/news_img_anywhere/droplet/nia_droplet.php');
 return $output;